((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B,D={
aut(){return new D.lS(null)},
lS:function lS(d){this.a=d},
Qh:function Qh(){this.c=this.a=null},
ai_:function ai_(){},
ai0:function ai0(d){this.a=d},
ai1:function ai1(d){this.a=d},
ahZ:function ahZ(d,e){this.a=d
this.b=e},
ahY:function ahY(){},
uJ:function uJ(d,e,f,g){var _=this
_.c=d
_.d=e
_.e=f
_.a=g},
Qi:function Qi(){this.d=!1
this.c=this.a=null},
ai4:function ai4(d){this.a=d},
ai3:function ai3(d){this.a=d},
ai5:function ai5(d){this.a=d},
ai2:function ai2(d){this.a=d},
DB:function DB(d){this.a=d},
Se:function Se(d,e){var _=this
_.d=$
_.d0$=d
_.aV$=e
_.c=_.a=null},
ajU:function ajU(d){this.a=d},
F0:function F0(d,e,f){this.c=d
this.d=e
this.a=f},
UV:function UV(){var _=this
_.d=0
_.e=""
_.f=!1
_.c=_.a=_.r=null},
amL:function amL(d,e){this.a=d
this.b=e},
amK:function amK(d,e){this.a=d
this.b=e},
C_:function C_(d,e){this.c=d
this.a=e},
Og:function Og(d,e){var _=this
_.d=$
_.d0$=d
_.aV$=e
_.c=_.a=null},
Fs:function Fs(){},
FL:function FL(){}},L,H,M,C,N,O,F,G,I,E,K,P
A=c[0]
B=c[2]
D=a.updateHolder(c[3],D)
L=c[27]
H=c[28]
M=c[17]
C=c[26]
N=c[11]
O=c[20]
F=c[12]
G=c[15]
I=c[9]
E=c[24]
K=c[29]
P=c[16]
D.lS.prototype={
ag(){return new D.Qh()}}
D.Qh.prototype={
vM(d){return this.ab1(d)},
ab1(d){var x=0,w=A.O(y.v)
var $async$vM=A.P(function(e,f){if(e===1)return A.L(f,w)
for(;;)switch(x){case 0:x=2
return A.T(N.vF(A.hd(d,0,null),O.eH),$async$vM)
case 2:if(!f)A.G8().$1("Could not launch "+d)
return A.M(null,w)}})
return A.N($async$vM,w)},
L(d){var x,w,v,u,t,s=null,r=y.A,q=A.bc(d,s,r).w.a.a,p=q>1100,o=q>700&&q<=1100,n=q<=700
r=A.bc(d,s,r).w
x=n?24:48
w=B.ei.bN(0.08)
v=A.cc(30)
u=A.iF(B.ei.bN(0.4),1)
t=y.u
v=A.cz(s,A.f2(A.c([new D.DB(s),B.c7,C.Vl],t),B.x,B.bl,0),B.r,s,s,new A.bB(w,s,u,v,s,s,B.P),s,s,E.nj,C.EK,s,s,s)
if(p)w=64
else w=o?48:40
w=A.aqQ(A.bF("Ibrahim Haji",s,s,s,A.d3(s,s,B.k,s,s,s,s,s,s,s,s,w,s,s,B.cq,s,1.1,!0,s,-1,s,s,s,s,s,s),s,s),new D.ai_())
u=p?28:22
r=A.di(A.eT(new A.eo(C.m1,new A.bT(new A.ad(x,0,x,0),new F.cW(A.cP(A.c([v,w,C.ld,new D.F0(C.I_,u,s),C.Pr,A.bF("Building production-grade mobile apps, high-performance backends, and private cloud infrastructure with Flutter & Rust.",s,s,s,A.d3(s,s,B.eq,s,s,s,s,s,s,s,s,n?16:18,s,s,s,s,1.7,!0,s,s,s,s,s,s,s,s),s,s),C.Pu,F.mT(G.bg,A.c([new D.uJ("View Projects",!0,new D.ai0(d),s),new D.uJ("Contact Me",!1,new D.ai1(d),s)],t),16,16)],t),B.a9,B.hz,B.K),B.v,s),s),s),s,s),r.a.b*0.92,s)
x=n?24:48
w=n?64:100
return A.cz(s,F.AA(A.cP(A.c([r,C.DX,new A.bT(new A.ad(x,w,x,w),new F.cW(A.eT(new A.eo(C.m1,A.cP(A.c([A.f2(A.c([A.cz(s,s,B.r,s,s,C.AI,s,6,s,s,s,s,6),B.c7,C.Vw],t),B.x,B.K,0),C.ld,A.a9n(s,s,s,B.bQ,s,s,!0,s,C.QE,B.aH,s,s,B.b1,B.aI),C.ld,C.Vf,P.fd,F.mT(G.bg,A.c([this.CD(d,"Secure Journal","CLI + Dioxus + Axum + SQLx","A private journaling app with end-to-end encryption and Rust backend.","https://github.com/Cobalt-Labs/cobalt_journal","01","Private App"),this.CD(d,"Cobalt Cloud","Rust Backend + Dioxus Frontend","Self-hosted private cloud running on my laptop HDD.","https://github.com/Cobalt-Labs/cobaltdev/tree/main/cobalt_cloud","02","Infrastructure"),this.CD(d,"Encrypt Notepad","Hybrid Mobile + Desktop","Production apps using Flutter frontend + Rust core via FFI.","https://github.com/ibrahim-3595/Encrypt-Notepad","03","Production App")],t),24,24)],t),B.a9,B.x,B.K),s),s,s),B.cN,s),s),A.cz(s,C.C7,B.r,s,s,C.AL,s,s,s,C.Ey,s,s,1/0)],t),B.aL,B.x,B.K),B.cK),B.r,s,s,C.AK,s,s,s,s,s,s,s)},
CD(d,e,f,g,h,i,j){var x=null,w=A.bc(d,x,y.A).w.a.a,v=w<450?B.c.d5(w-48,0,1/0):360,u=A.bF(i,x,x,x,A.d3(x,x,B.L.bN(0.45),x,x,x,x,x,x,x,x,12,x,x,B.cq,x,x,!0,x,2,x,x,x,x,x,x),x,x),t=B.L.bN(0.1),s=A.iF(B.L.bN(0.25),1),r=A.cc(20),q=y.u
r=A.f2(A.c([u,C.F0,A.cz(x,A.bF(j.toUpperCase(),x,x,x,C.Tc,x,x),B.r,x,x,new A.bB(t,x,s,r,x,x,B.P),x,x,x,C.EC,x,x,x)],q),B.x,B.K,0)
s=A.bF(e,x,x,x,C.RV,x,x)
t=A.bF(g,x,x,x,C.UI,x,x)
u=y.s
u=A.a0(new A.a4(A.c(f.split(" + "),y.x),new D.ahY(),u),u.i("at.E"))
return A.di(F.kd(A.cP(A.c([r,G.bq,s,M.ig,t,G.bq,F.mT(G.bg,u,8,8),B.ie,A.cz(x,C.No,B.r,x,x,new A.bB(x,x,x,A.cc(12),A.c([new A.bQ(0,B.aU,B.co.bN(0.3),B.f,16)],y.c),B.hp,B.P),x,x,x,B.nm,x,x,x)],q),B.a9,B.x,B.K),new D.ahZ(this,h),L.h3),x,v)}}
D.uJ.prototype={
ag(){return new D.Qi()}}
D.Qi.prototype={
L(d){var x,w,v,u=this,t=null,s=u.a.e,r=new A.aM(new Float64Array(16))
r.dq()
r.jn(0,u.d?-2:0,0)
if(u.a.d){x=A.cc(12)
w=B.co.bN(u.d?0.55:0.35)
x=new A.bB(t,t,t,x,A.c([new A.bQ(0,B.aU,w,G.dH,u.d?28:18)],y.c),C.Gq,B.P)}else{x=u.d?B.ei.bN(0.12):B.ei.bN(0.06)
x=new A.bB(x,t,A.iF(B.L.bN(u.d?0.6:0.35),1),A.cc(12),t,t,B.P)}w=u.a
v=w.c
return A.eu(A.eX(t,A.Xg(A.bF(v,t,t,t,A.d3(t,t,w.d?B.k:B.cL,t,t,t,t,t,t,t,t,16,t,t,B.aA,t,t,!0,t,t,t,t,t,t,t,t),t,t),B.bZ,x,E.nd,t,C.EQ,r,t),B.a_,!1,t,t,t,t,t,t,t,t,t,t,t,t,t,t,s,t,t,t,t,t,t),B.bA,t,new D.ai4(u),new D.ai5(u),t)}}
D.DB.prototype={
ag(){return new D.Se(null,null)}}
D.Se.prototype={
az(){this.aJ()
var x=A.bH(null,B.h0,null,null,this)
x.Hz(!0)
this.d=x},
l(){var x=this.d
x===$&&A.a()
x.l()
this.a0s()},
L(d){var x=this.d
x===$&&A.a()
return A.hR(x,new D.ajU(this),null)}}
D.F0.prototype={
ag(){return new D.UV()}}
D.UV.prototype={
az(){this.aJ()
this.OU()},
l(){var x=this.r
if(x!=null)x.aT()
this.aB()},
OU(){var x,w,v,u=this,t=u.r
if(t!=null)t.aT()
x=u.a.c[u.d]
t=u.f
w=!t
if(w&&u.e.length<x.length)v=80
else if(w&&u.e.length===x.length)v=1800
else v=t&&u.e.length!==0?40:120
u.r=A.bK(A.dI(0,v),new D.amL(u,x))},
L(d){var x=null
return A.f2(A.c([A.bF(this.e,x,x,x,A.d3(x,x,B.cL,x,x,x,x,x,x,x,x,this.a.d,x,x,B.aA,x,x,!0,x,x,x,x,x,x,x,x),x,x),new D.C_(this.a.d,x)],y.u),B.x,B.bl,0)}}
D.C_.prototype={
ag(){return new D.Og(null,null)}}
D.Og.prototype={
az(){this.aJ()
var x=A.bH(null,B.dp,null,null,this)
x.Hz(!0)
this.d=x},
l(){var x=this.d
x===$&&A.a()
x.l()
this.a0b()},
L(d){var x=null,w=this.d
w===$&&A.a()
return new A.co(w,!1,A.cz(x,x,B.r,B.L,x,x,x,this.a.c*0.9,C.ES,x,x,x,3),x)}}
D.Fs.prototype={
l(){var x=this,w=x.aV$
if(w!=null)w.I(x.geh())
x.aV$=null
x.aB()},
bj(){this.c3()
this.bW()
this.ei()}}
D.FL.prototype={
l(){var x=this,w=x.aV$
if(w!=null)w.I(x.geh())
x.aV$=null
x.aB()},
bj(){this.c3()
this.bW()
this.ei()}}
var z=a.updateTypes([])
D.ai_.prototype={
$1(d){return C.Gr.Fl(d)},
$S:77}
D.ai0.prototype={
$0(){var x=y.q
return A.z2(this.a,"/portfolio",x,x)},
$S:0}
D.ai1.prototype={
$0(){var x=y.q
return A.z2(this.a,"/contact",x,x)},
$S:0}
D.ahZ.prototype={
$0(){return this.a.vM(this.b)},
$S:0}
D.ahY.prototype={
$1(d){var x=null,w=B.k.bN(0.05),v=A.iF(H.j7,1),u=A.cc(8)
return A.cz(x,A.bF(d,x,x,x,C.Uz,x,x),B.r,x,x,new A.bB(w,x,v,u,x,x,B.P),x,x,x,C.Ez,x,x,x)},
$S:487}
D.ai4.prototype={
$1(d){var x=this.a
return x.aj(new D.ai3(x))},
$S:46}
D.ai3.prototype={
$0(){return this.a.d=!0},
$S:0}
D.ai5.prototype={
$1(d){var x=this.a
return x.aj(new D.ai2(x))},
$S:31}
D.ai2.prototype={
$0(){return this.a.d=!1},
$S:0}
D.ajU.prototype={
$2(d,e){var x=null,w=this.a.d
w===$&&A.a()
w=w.x
w===$&&A.a()
return A.cz(x,x,B.r,x,x,new A.bB(B.L,x,x,x,A.c([new A.bQ(2*w,B.aU,B.L,B.f,6+10*w)],y.c),x,B.dg),x,8,x,x,x,x,8)},
$S:136}
D.amL.prototype={
$0(){var x=this.a
if(x.c==null)return
x.aj(new D.amK(x,this.b))
x.OU()},
$S:0}
D.amK.prototype={
$0(){var x=this,w=x.a,v=w.f,u=!v
if(u&&w.e.length<x.b.length)w.e=B.d.af(x.b,0,w.e.length+1)
else if(u&&w.e.length===x.b.length)w.f=!0
else if(v&&w.e.length!==0)w.e=B.d.af(x.b,0,w.e.length-1)
else{w.f=!1
v=w.d
w.a.toString
w.d=(v+1)%4}},
$S:0};(function aliases(){var x=D.Fs.prototype
x.a0b=x.l
x=D.FL.prototype
x.a0s=x.l})();(function inheritance(){var x=a.mixinHard,w=a.inheritMany,v=a.inherit
w(A.V,[D.lS,D.uJ,D.DB,D.F0,D.C_])
w(A.a2,[D.Qh,D.Qi,D.FL,D.UV,D.Fs])
w(A.fP,[D.ai_,D.ahY,D.ai4,D.ai5])
w(A.iM,[D.ai0,D.ai1,D.ahZ,D.ai3,D.ai2,D.amL,D.amK])
v(D.Se,D.FL)
v(D.ajU,A.nK)
v(D.Og,D.Fs)
x(D.Fs,A.dx)
x(D.FL,A.dx)})()
A.lf(b.typeUniverse,JSON.parse('{"uJ":{"V":[],"f":[]},"DB":{"V":[],"f":[]},"F0":{"V":[],"f":[]},"C_":{"V":[],"f":[]},"lS":{"V":[],"f":[]},"Qh":{"a2":["lS"]},"Qi":{"a2":["uJ"]},"Se":{"a2":["DB"]},"UV":{"a2":["F0"]},"Og":{"a2":["C_"]}}'))
var y={c:A.W("p<bQ>"),r:A.W("p<w>"),x:A.W("p<C>"),u:A.W("p<f>"),s:A.W("a4<C,jY>"),A:A.W("f_"),q:A.W("G?"),v:A.W("~")};(function constants(){var x=a.makeConstList
C.m1=new A.a8(0,1200,0,1/0)
C.AO=new A.bQ(0,B.aU,B.L,B.f,6)
C.Ib=x([C.AO],y.c)
C.AI=new A.bB(B.L,null,null,null,C.Ib,null,B.dg)
C.iQ=new A.dE(1,1)
C.CV=new A.w(1,0.058823529411764705,0.043137254901960784,0.11764705882352941,B.e)
C.D9=new A.w(1,0.08235294117647059,0.050980392156862744,0.1803921568627451,B.e)
C.Dd=new A.w(1,0.10196078431372549,0.043137254901960784,0.2,B.e)
C.Id=x([B.el,C.CV,C.D9,C.Dd],y.r)
C.Hg=x([0,0.4,0.7,1],A.W("p<D>"))
C.Gt=new A.hu(E.ch,C.iQ,B.br,C.Id,C.Hg,null)
C.AK=new A.bB(null,null,null,null,null,C.Gt,B.P)
C.mS=new A.w(0.13333333333333333,0.5450980392156862,0.3607843137254902,0.9647058823529412,B.e)
C.Aw=new A.aN(C.mS,1,B.t,-1)
C.Ax=new A.cO(C.Aw,B.n,B.n,B.n)
C.AL=new A.bB(null,null,C.Ax,null,null,null,B.P)
C.Cx=new A.w(1,0.2784313725490196,0.3333333333333333,0.4117647058823529,B.e)
C.TA=new A.j(!0,C.Cx,null,null,null,null,14,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null)
C.Vg=new A.bJ("\xa9 2026 CobaltDev \xb7 Built with Flutter & Rust",null,C.TA,null,null,null,null,null,null)
C.C7=new A.iJ(B.a7,null,null,C.Vg,null)
C.DX=new I.rf(1,null,null,C.mS,null)
C.Ey=new A.ad(0,48,0,48)
C.Ez=new A.ad(10,4,10,4)
C.EC=new A.ad(12,4,12,4)
C.EK=new A.ad(16,6,16,6)
C.EQ=new A.ad(32,18,32,18)
C.ES=new A.ad(4,0,0,0)
C.DZ=new I.rf(null,12,12,H.j7,null)
C.F0=new A.xt(1,B.k8,C.DZ,null)
C.Gq=new A.hu(E.ch,C.iQ,B.br,E.of,null,null)
C.It=x([B.cL,B.L,E.mN,B.mA],y.r)
C.Gr=new A.hu(E.ch,C.iQ,B.br,C.It,null,null)
C.I_=x(["Flutter + Rust Developer","Creative Problem Solver","UI/UX Enthusiast","Systems Engineer"],y.x)
C.VA=new A.bJ("View Project",null,B.zu,null,null,null,null,null,null)
C.Ff=new A.dV(57499,"MaterialIcons",!0)
C.Fw=new A.lT(C.Ff,16,B.k,null,null)
C.H0=x([C.VA,B.c7,C.Fw],y.u)
C.No=new A.tr(B.aq,B.x,B.bl,B.aL,null,B.bT,null,0,C.H0,null)
C.ld=new A.cs(null,14,null,null)
C.Pr=new A.cs(null,28,null,null)
C.Pu=new A.cs(null,52,null,null)
C.QD=new A.dM("Projects",null,null,B.an,null,null,null,null,null,null,E.zv)
C.I3=x([C.QD],A.W("p<da>"))
C.RG=new A.j(!0,B.k,null,"Inter",null,null,40,B.cq,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null)
C.QE=new A.dM("Featured ",C.I3,null,B.an,null,null,null,null,null,null,C.RG)
C.RV=new A.j(!0,B.k,null,null,null,null,22,B.cq,null,null,null,null,1.2,null,null,null,null,null,null,null,null,null,null,null,null,null)
C.Tc=new A.j(!0,B.cL,null,null,null,null,10,B.bi,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null)
C.Uz=new A.j(!0,B.eq,null,null,null,null,11,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null)
C.UI=new A.j(!0,K.jf,null,null,null,null,15,null,null,null,null,null,1.6,null,null,null,null,null,null,null,null,null,null,null,null,null)
C.U0=new A.j(!0,K.jf,null,null,null,null,18,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null)
C.Vf=new A.bJ("Real stuff I've built with passion and code.",null,C.U0,null,null,null,null,null,null)
C.Rr=new A.j(!0,B.cL,null,null,null,null,11,B.bi,null,1.2,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null)
C.Vl=new A.bJ("AVAILABLE FOR WORK",null,C.Rr,null,null,null,null,null,null)
C.S0=new A.j(!0,B.cL,null,null,null,null,12,B.bi,null,1.5,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null)
C.Vw=new A.bJ("PORTFOLIO",null,C.S0,null,null,null,null,null,null)})()};
(a=>{a["JjjTzrpJPORL8FXkJmgN1gB0tG0="]=a.current})($__dart_deferred_initializers__);