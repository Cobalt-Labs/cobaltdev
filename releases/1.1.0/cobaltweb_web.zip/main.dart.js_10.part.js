((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B
A=c[0]
B=c[27]
var z=a.updateTypes([]);(function constants(){B.h3=new A.ad(32,32,32,32)})()};
(a=>{a["JNLP0jRtAGQP7nwqUbu1JEkC6Hg="]=a.current})($__dart_deferred_initializers__);