((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B,C
A=c[0]
B=c[2]
C=c[28]
var z=a.updateTypes([]);(function constants(){C.j7=new A.w(0.10196078431372549,1,1,1,B.e)})()};
(a=>{a["A8iISvlQ6H3wLPEdJTGiGx7aIZ8="]=a.current})($__dart_deferred_initializers__);