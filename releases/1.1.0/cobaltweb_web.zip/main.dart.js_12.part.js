((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B
A=c[0]
B=c[17]
var z=a.updateTypes([]);(function constants(){B.ig=new A.cs(null,8,null,null)})()};
(a=>{a["Gie7tgvnNAUwr8LFv3eiI0l8ORU="]=a.current})($__dart_deferred_initializers__);