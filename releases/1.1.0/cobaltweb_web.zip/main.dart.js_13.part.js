((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B,H,E={
aCy(){return new E.ns(null)},
ns:function ns(d){this.a=d}},C,F,I,D,G,K
A=c[0]
B=c[2]
H=c[17]
E=a.updateHolder(c[4],E)
C=c[13]
F=c[14]
I=c[18]
D=c[12]
G=c[15]
K=c[16]
E.ns.prototype={
L(d){var x=null,w=A.bc(d,x,y.h).w.a.a,v=w<700,u=v?24:48,t=v?40:80,s=y.e,r=A.cP(A.c([A.bF("About Me",x,x,x,A.d3(x,x,B.k,x,x,x,x,x,x,x,x,w>900?48:36,x,x,B.aA,x,x,!0,x,-1,x,x,x,x,x,x),x,x),B.dS,C.VI],s),B.a9,B.x,B.K),q=v?32:48
return D.AA(new A.bT(new A.ad(u,t,u,t),A.cP(A.c([new D.cW(r,B.v,x),F.d5,new D.cW(A.eT(new A.eo(C.AH,D.kd(A.cP(C.Hx,B.a9,B.x,B.K),x,new A.ad(q,q,q,q)),x),x,x),B.aW,x),F.d5,new D.cW(D.mT(G.zN,A.c([this.DN(d,"7+","Years Coding"),this.DN(d,"10+","Production Apps"),this.DN(d,"100%","Rust Backend")],s),24,24),B.W,x),K.fd],s),B.a9,B.x,B.K),x),B.cK)},
DN(d,e,f){var x=null,w=A.bc(d,x,y.h).w.a.a,v=w<400,u=v?B.c.d5(w-48,0,1/0):200
v=v?24:32
return A.di(D.kd(A.cP(A.c([A.bF(e,x,x,x,C.Tw,x,x),H.ig,A.bF(f,x,x,x,C.SY,B.bP,x)],y.e),B.aL,B.x,B.K),x,new A.ad(v,v,v,v)),x,u)}}
var z=a.updateTypes([]);(function inheritance(){var x=a.inherit
x(E.ns,A.aB)})()
A.lf(b.typeUniverse,JSON.parse('{"ns":{"aB":[],"f":[]}}'))
var y={e:A.W("p<f>"),h:A.W("f_")};(function constants(){var x=a.makeConstList
C.AH=new A.a8(0,800,0,1/0)
C.Vz=new A.bJ("My Journey",null,I.zt,null,null,null,null,null,null)
C.zr=new A.j(!0,B.B,null,null,null,null,16,null,null,null,null,null,1.7,null,null,null,null,null,null,null,null,null,null,null,null,null)
C.VH=new A.bJ("I've been programming for over 7 years. What started as simple mobile applications turned into a deep passion for system-level programming and highly optimized backends.\n\nToday, I build seamless, native-feeling experiences using Flutter and power them with unyielding Rust backends.",null,C.zr,null,null,null,null,null,null)
C.Vu=new A.bJ("Currently, I'm focused on Cobalt Cloud\u2014a self-hosted platform running on raw Rust\u2014and building cross-platform Dioxus frontend apps.",null,C.zr,null,null,null,null,null,null)
C.Hx=x([C.Vz,G.bq,C.VH,G.bq,C.Vu],y.e)
C.SY=new A.j(!0,B.B,null,null,null,null,15,B.U,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null)
C.Tw=new A.j(!0,B.L,null,null,null,null,40,B.aA,null,-1,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null)
C.VI=new A.bJ("From simple interfaces to highly optimized Rust backends.",null,F.im,null,null,null,null,null,null)})()};
(a=>{a["nh+n5ecR4DSa99+HSaju8RfKU+g="]=a.current})($__dart_deferred_initializers__);