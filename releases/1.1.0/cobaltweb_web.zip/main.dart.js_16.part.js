((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B,K,L,H,M,D={
aHs(){return new D.pB(null)},
pB:function pB(d){this.a=d},
abE:function abE(d){this.a=d}},C,I,F,N,O,P,E,G,Q
A=c[0]
B=c[2]
K=c[27]
L=c[28]
H=c[14]
M=c[18]
D=a.updateHolder(c[5],D)
C=c[36]
I=c[32]
F=c[31]
N=c[23]
O=c[35]
P=c[21]
E=c[12]
G=c[15]
Q=c[16]
D.pB.prototype={
L(d){var x=this,w=null,v=A.bc(d,w,y.h).w.a.a,u=v<700,t=u?24:48,s=u?40:80,r=y.e,q=A.cP(A.c([A.bF("What I Build",w,w,w,A.d3(w,w,B.k,w,w,w,w,w,w,w,w,v>1000?48:36,w,w,B.aA,w,w,!0,w,-1,w,w,w,w,w,w),w,w),B.dS,C.Vq],r),B.a9,B.x,B.K),p=E.mT(G.bg,A.c([x.wk(d,"Mobile & Desktop Apps","Pixel-perfect Flutter applications with clean architecture and smooth animations. Cross-platform (iOS, Android, Desktop, Web).","Flutter \u2022 Dart \u2022 Riverpod",C.Fr),x.wk(d,"Rust Backend Systems","High-performance, memory-safe backends using Axum, SQLx, and object_store. Built for speed and reliability.","Rust \u2022 Axum \u2022 SQLx",C.Fq),x.wk(d,"Private Cloud Infrastructure","Self-hosted cloud solutions running on your own hardware. Drag & drop file storage with full control.","Rust \u2022 object_store \u2022 Dioxus",C.Fl),x.wk(d,"Performance & Systems","Low-level optimizations, FFI bridges, CLI tools, and experimental systems programming in Rust.","Rust \u2022 FFI \u2022 DSA",C.Fs)],r),24,24),o=u?1/0:w,n=u?32:48
return E.AA(new A.bT(new A.ad(t,s,t,s),A.cP(A.c([new E.cW(q,B.v,w),H.d5,new E.cW(p,B.aW,w),F.lc,new E.cW(A.eT(A.di(E.kd(A.cP(A.c([C.VB,N.dT,C.VJ,B.ie,A.eu(A.eX(w,A.cz(w,C.Vi,B.r,w,w,new A.bB(w,w,w,A.cc(12),A.c([new A.bQ(0,B.aU,B.co.bN(0.35),G.dH,20)],y.c),B.hp,B.P),w,w,w,I.nn,w,w,w),B.a_,!1,w,w,w,w,w,w,w,w,w,w,w,w,w,w,new D.abE(d),w,w,w,w,w,w),B.bA,w,w,w,w)],r),B.aL,B.x,B.K),w,new A.ad(n,n,n,n)),w,o),w,w),B.W,w),Q.fd],r),B.a9,B.x,B.K),w),B.cK)},
wk(d,e,f,g,h){var x,w,v=null,u=A.bc(d,v,y.h).w.a.a,t=u<450?B.c.d5(u-48,0,1/0):360,s=B.L.bN(0.1),r=A.cc(10),q=A.iF(B.L.bN(0.2),1)
r=A.cz(v,A.Jy(h,B.L,v,22),B.r,v,v,new A.bB(s,v,q,r,v,v,B.P),v,v,v,C.EA,v,v,v)
q=A.bF(e,v,v,v,F.ln,v,v)
s=A.bF(f,v,v,v,F.lo,v,v)
x=A.cc(6)
w=A.iF(L.j7,1)
return A.di(E.kd(A.cP(A.c([r,C.Pq,q,B.dS,s,G.bq,A.cz(v,A.bF(g,v,v,v,C.SC,v,v),B.r,v,v,new A.bB(P.mw,v,w,x,v,v,B.P),v,v,v,O.nk,v,v,v)],y.e),B.a9,B.x,B.K),v,K.h3),v,t)}}
var z=a.updateTypes([])
D.abE.prototype={
$0(){var x=y.a
return A.z2(this.a,"/contact",x,x)},
$S:0};(function inheritance(){var x=a.inherit
x(D.pB,A.aB)
x(D.abE,A.iM)})()
A.lf(b.typeUniverse,JSON.parse('{"pB":{"aB":[],"f":[]}}'))
var y={c:A.W("p<bQ>"),e:A.W("p<f>"),h:A.W("f_"),a:A.W("G?")};(function constants(){C.EA=new A.ad(12,12,12,12)
C.Fl=new A.dV(63052,"MaterialIcons",!1)
C.Fq=new A.dV(63667,"MaterialIcons",!1)
C.Fr=new A.dV(983160,"MaterialIcons",!1)
C.Fs=new A.dV(983477,"MaterialIcons",!1)
C.Pq=new A.cs(null,20,null,null)
C.SC=new A.j(!0,B.eq,null,null,null,null,13,B.U,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null)
C.Vi=new A.bJ("Start a Project",null,I.zs,null,null,null,null,null,null)
C.Vq=new A.bJ("From beautiful mobile apps to high-performance Rust backends.",null,H.im,null,null,null,null,null,null)
C.VB=new A.bJ("Ready to build something great?",null,M.zt,B.bP,null,null,null,null,null)
C.VJ=new A.bJ("Let's turn your idea into a production-ready product.",null,B.il,B.bP,null,null,null,null,null)})()};
(a=>{a["pYuCTZhhW3S5NRjBvHKyiO0fGNM="]=a.current})($__dart_deferred_initializers__);