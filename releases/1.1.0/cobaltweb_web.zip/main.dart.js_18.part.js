((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,C,B
A=c[0]
C=c[2]
B=c[31]
var z=a.updateTypes([]);(function constants(){B.lc=new A.cs(null,100,null,null)
B.ln=new A.j(!0,null,null,null,null,null,20,C.aA,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null)
B.lo=new A.j(!0,C.B,null,null,null,null,15,null,null,null,null,null,1.6,null,null,null,null,null,null,null,null,null,null,null,null,null)})()};
(a=>{a["e994P5KEVXH4rQuYIDcu5goKKKw="]=a.current})($__dart_deferred_initializers__);