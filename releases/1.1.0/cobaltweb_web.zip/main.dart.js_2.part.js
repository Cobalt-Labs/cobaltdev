((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var B,D,A={rK:function rK(d,e){this.a=d
this.b=e},ae9:function ae9(){},XP:function XP(){},
aMg(d){switch(d.a){case 0:return D.kI
case 2:return D.y8
case 1:return D.y7
case 3:return C.MI
case 4:return D.y9}},
vF(d,e){var x=0,w=B.O(y.a),v,u
var $async$vF=B.P(function(f,g){if(f===1)return B.L(g,w)
for(;;)switch(x){case 0:if(e===C.Gn||e===C.Go)u=!(d.glh()==="https"||d.glh()==="http")
else u=!1
if(u)throw B.i(B.hT(d,"url","To use an in-app web view, you must provide an http(s) URL."))
v=$.aAL().tQ(d.k(0),new B.JR(A.aMg(e),new B.JC(!0,!0,D.uf),null))
x=1
break
case 1:return B.M(v,w)}})
return B.N($async$vF,w)}},C
B=c[0]
D=c[2]
A=a.updateHolder(c[11],A)
C=c[20]
A.rK.prototype={
E(){return"LaunchMode."+this.b}}
A.ae9.prototype={}
A.XP.prototype={}
var z=a.updateTypes([]);(function inheritance(){var x=a.inherit,w=a.inheritMany
x(A.rK,B.uC)
w(B.G,[A.ae9,A.XP])})()
var y={a:B.W("I")};(function constants(){C.YL=new A.XP()
C.YR=new A.ae9()
C.YY=new A.rK(0,"platformDefault")
C.Gn=new A.rK(1,"inAppWebView")
C.Go=new A.rK(2,"inAppBrowserView")
C.eH=new A.rK(3,"externalApplication")
C.MI=new B.p8(3,"externalApplication")})()};
(a=>{a["k39OlUObrAaxXxuUrZutPc2Yh24="]=a.current})($__dart_deferred_initializers__);