((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B
A=c[0]
B=c[35]
var z=a.updateTypes([]);(function constants(){B.nk=new A.ad(12,6,12,6)})()};
(a=>{a["nV7ZiebNopWqYby971zhzfcH9R8="]=a.current})($__dart_deferred_initializers__);