((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B,C
A=c[0]
B=c[2]
C=c[21]
var z=a.updateTypes([]);(function constants(){C.mw=new A.w(1,0.11764705882352941,0.10196078431372549,0.21176470588235294,B.e)})()};
(a=>{a["YFWwT43rADI6VVdg5T/rnoF1ucQ="]=a.current})($__dart_deferred_initializers__);