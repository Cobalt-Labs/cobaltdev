((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B,L,M,H,F,N,O,P,C={
aGD(){return new C.pa(null)},
pa:function pa(d){this.a=d},
a7R:function a7R(d){this.a=d},
a7S:function a7S(d){this.a=d},
a7T:function a7T(d){this.a=d},
a7U:function a7U(d){this.a=d}},D,I,G,Q,E,K,R,S
A=c[0]
B=c[2]
L=c[27]
M=c[17]
H=c[14]
F=c[31]
N=c[23]
O=c[11]
P=c[35]
C=a.updateHolder(c[6],C)
D=c[34]
I=c[22]
G=c[33]
Q=c[20]
E=c[12]
K=c[15]
R=c[29]
S=c[16]
C.pa.prototype={
L(d){var x=this,w=null,v="Available",u="Open Source",t=A.bc(d,w,y.h).w.a.a,s=t<700,r=s?24:48,q=s?40:80,p=y.e,o=A.cP(A.c([A.bF("Products & Tools",w,w,w,A.d3(w,w,B.k,w,w,w,w,w,w,w,w,t>900?48:36,w,w,B.aA,w,w,!0,w,-1,w,w,w,w,w,w),w,w),B.dS,D.Vo],p),B.a9,B.x,B.K),n=E.mT(K.bg,A.c([x.rr(d,"Cobalt Web","Flutter App / Web","Implemented BLoC and Freezed for better state management. Deployed and live.","Live",new C.a7R(x)),x.rr(d,"Cobalt Cloud","Rust + Dioxus Cloud Storage","Self-hosted cloud with Dioxus frontend and Axum Rust backend.",v,new C.a7S(d)),x.abY(d,"Secure Journal","Encrypted journaling app","CLI + Dioxus frontend with Axum + SQLx backend. Your thoughts stay yours.",v),x.rr(d,"Encrypt Notepad","Rust + Flutter via FFI","Structured UI and performant backend with memory safety.",u,new C.a7T(x)),x.rr(d,"Rust DSA Library","Algorithms & Data Structures","Clean, well-documented implementations for learning and production use.",u,new C.a7U(x))],p),24,24),m=s?32:48
return E.AA(new A.bT(new A.ad(r,q,r,q),A.cP(A.c([new E.cW(o,B.v,w),H.d5,new E.cW(n,B.aW,w),F.lc,new E.cW(A.eT(E.kd(A.cP(D.HA,B.aL,B.x,B.K),w,new A.ad(m,m,m,m)),w,w),B.W,w),S.fd],p),B.a9,B.x,B.K),w),B.cK)},
oE(d){return this.a92(d)},
a92(d){var x=0,w=A.O(y.f),v=1,u=[],t,s,r,q
var $async$oE=A.P(function(e,f){if(e===1){u.push(f)
x=v}for(;;)switch(x){case 0:r=A.hd(d,0,null)
v=3
x=6
return A.T(O.vF(r,Q.eH),$async$oE)
case 6:v=1
x=5
break
case 3:v=2
q=u.pop()
t=A.aq(q)
A.G8().$1("Could not launch "+d+": "+A.k(t))
x=5
break
case 2:x=1
break
case 5:return A.M(null,w)
case 1:return A.L(u.at(-1),w)}})
return A.N($async$oE,w)},
rr(d,e,f,g,h,i){var x,w,v,u,t,s,r,q,p,o=null,n=A.bc(d,o,y.h).w.a.a
switch(h){case"Live":x=I.fN.bN(0.1)
w=I.fN
break
case"Available":x=B.L.bN(0.1)
w=B.L
break
default:x=B.k.bN(0.04)
w=B.eq}v=n<450?B.c.d5(n-48,0,1/0):360
u=A.bF(e,o,o,o,F.ln,o,o)
t=A.bF(f,o,o,o,G.zw,o,o)
s=A.bF(g,o,o,o,F.lo,o,o)
r=A.cc(6)
q=A.iF(w.bN(0.3),1)
p=y.e
r=A.c([A.cz(o,A.bF(h,o,o,o,A.d3(o,o,w,o,o,o,o,o,o,o,o,13,o,o,B.aA,o,o,!0,o,o,o,o,o,o,o,o),o,o),B.r,o,o,new A.bB(x,o,q,r,o,o,B.P),o,o,o,P.nk,o,o,o)],p)
if(i!=null)r.push(A.Jy(G.nT,B.L.bN(0.7),o,18))
return A.di(E.kd(A.cP(A.c([u,G.z5,t,N.dT,s,K.bq,A.f2(r,B.hA,B.K,0)],p),B.a9,B.x,B.K),i,L.h3),o,v)},
abY(d,e,f,g,h){return this.rr(d,e,f,g,h,null)}}
var z=a.updateTypes([])
C.a7R.prototype={
$0(){return this.a.oE("https://cobaltdev.vercel.app")},
$S:0}
C.a7S.prototype={
$0(){var x=y.a
return A.z2(this.a,"/portfolio",x,x)},
$S:0}
C.a7T.prototype={
$0(){return this.a.oE("https://github.com/ibrahim-3595/Encrypt-Notepad")},
$S:0}
C.a7U.prototype={
$0(){return this.a.oE("https://github.com/ibrahim-3595")},
$S:0};(function inheritance(){var x=a.inherit,w=a.inheritMany
x(C.pa,A.aB)
w(A.iM,[C.a7R,C.a7S,C.a7T,C.a7U])})()
A.lf(b.typeUniverse,JSON.parse('{"pa":{"aB":[],"f":[]}}'))
var y={e:A.W("p<f>"),h:A.W("f_"),a:A.W("G?"),f:A.W("~")};(function constants(){var x=a.makeConstList
D.Vn=new A.bJ("More products coming soon...",null,B.il,B.bP,null,null,null,null,null)
D.SO=new A.j(!0,R.jf,null,null,null,null,14,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null)
D.VF=new A.bJ("Follow the GitHub for updates.",null,D.SO,B.bP,null,null,null,null,null)
D.HA=x([D.Vn,M.ig,D.VF],y.e)
D.Vo=new A.bJ("Some of the tools and products I've built or am actively developing.",null,H.im,null,null,null,null,null,null)})()};
(a=>{a["yyg5ol5Z9N7b+6tgWXlrxya947w="]=a.current})($__dart_deferred_initializers__);