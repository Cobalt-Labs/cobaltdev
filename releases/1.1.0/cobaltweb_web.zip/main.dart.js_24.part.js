((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B,C
A=c[0]
B=c[2]
C=c[22]
var z=a.updateTypes([]);(function constants(){C.fN=new A.w(1,0.2901960784313726,0.8705882352941177,0.5019607843137255,B.e)})()};
(a=>{a["21fxNrJaKDkoCXdVDbGRxqQIY1Y="]=a.current})($__dart_deferred_initializers__);