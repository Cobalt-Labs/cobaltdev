((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,C,B
A=c[0]
C=c[2]
B=c[33]
var z=a.updateTypes([]);(function constants(){B.nT=new A.dV(62842,"MaterialIcons",!0)
B.z5=new A.cs(null,6,null,null)
B.zw=new A.j(!0,C.L,null,null,null,null,14,C.U,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null)})()};
(a=>{a["a49zwCCzSOHdHELDmLQmX3S0UlQ="]=a.current})($__dart_deferred_initializers__);