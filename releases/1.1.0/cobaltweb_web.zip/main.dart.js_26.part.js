((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B,M,G,K,H,N,O,I,C={
aGo(){return new C.p7(null)},
p7:function p7(d){this.a=d},
a7L:function a7L(d){this.a=d},
a7K:function a7K(d,e){this.a=d
this.b=e},
a7I:function a7I(d,e){this.a=d
this.b=e},
a7J:function a7J(d,e){this.a=d
this.b=e},
Uc:function Uc(d,e,f,g,h){var _=this
_.c=d
_.d=e
_.e=f
_.f=g
_.a=h}},D,L,P,Q,E,F,R
A=c[0]
B=c[2]
M=c[27]
G=c[14]
K=c[32]
H=c[31]
N=c[23]
O=c[11]
I=c[33]
C=a.updateHolder(c[7],C)
D=c[30]
L=c[10]
P=c[25]
Q=c[20]
E=c[12]
F=c[15]
R=c[16]
C.p7.prototype={
L(d){var x=this,w=null,v="https://github.com/ibrahim-3595",u=A.bc(d,w,y.x).w.a.a,t=u<700,s=t?24:48,r=t?40:80,q=y.u,p=A.cP(A.c([A.bF("My Portfolio",w,w,w,A.d3(w,w,B.k,w,w,w,w,w,w,w,w,u>1100?48:36,w,w,B.aA,w,w,!0,w,-1,w,w,w,w,w,w),w,w),B.dS,D.Vs],q),B.a9,B.x,B.K),o=x.DD("Mobile & Desktop Apps"),n=y.w,m=y.b,l=y.k,k=x.Dh(d,A.c([A.av(["title","Flutter + Rust Hybrid Apps","tech","Flutter \u2022 Rust \u2022 FFI","desc","Multiple production apps using Flutter for beautiful UI and Rust for high-performance core logic via FFI.","url",v],n,m),A.av(["title","Secure Journal App","tech","Flutter \u2022 Rust \u2022 SQLx","desc","Private journaling app with end-to-end encryption, Rust backend, and clean cross-platform UI.","url","https://github.com/ibrahim-3595/Secure-Journal"],n,m)],l)),j=x.DD("Rust Backend Systems"),i=x.Dh(d,A.c([A.av(["title","Cobalt Cloud","tech","Rust \u2022 Axum \u2022 Dioxus","desc","Self-hosted private cloud infrastructure with Dioxus frontend and Rust backend in cobalt_backend.","url","https://github.com/Cobalt-Labs/cobaltdev/tree/main/cobalt_cloud"],n,m),A.av(["title","Axum Microservices","tech","Rust \u2022 Axum \u2022 SQLx","desc","Scalable backend APIs and microservices built with Axum framework and SQLx for database operations.","url",v],n,m)],l)),h=x.DD("Systems & Experiments")
l=x.Dh(d,A.c([A.av(["title","Algorithms in Rust","tech","Rust \u2022 DSA","desc","Collection of data structures and algorithms implemented in Rust for learning and performance testing.","url",v],n,m),A.av(["title","Rust CLI Tools","tech","Rust \u2022 CLI \u2022 SQLx","desc","Command-line tools and utilities built with pure Rust for maximum performance and reliability.","url",v],n,m)],l))
n=t?1/0:w
m=t?32:48
return E.AA(new A.bT(new A.ad(s,r,s,r),A.cP(A.c([new E.cW(p,B.v,w),G.d5,new E.cW(o,D.El,w),F.bq,new E.cW(k,P.nc,w),G.d5,new E.cW(j,D.E4,w),F.bq,new E.cW(i,B.W,w),G.d5,new E.cW(h,D.E9,w),F.bq,new E.cW(l,D.Ec,w),H.lc,new E.cW(A.eT(A.di(E.kd(A.cP(A.c([D.VG,F.bq,A.eu(A.eX(w,A.cz(w,D.VK,B.r,w,w,new A.bB(w,w,w,A.cc(12),A.c([new A.bQ(0,B.aU,B.co.bN(0.35),F.dH,20)],y.c),B.hp,B.P),w,w,w,K.nn,w,w,w),B.a_,!1,w,w,w,w,w,w,w,w,w,w,w,w,w,w,new C.a7L(d),w,w,w,w,w,w),B.bA,w,w,w,w)],q),B.aL,B.x,B.K),w,new A.ad(m,m,m,m)),w,n),w,w),B.bF,w),R.fd],q),B.a9,B.x,B.K),w),B.cK)},
DD(d){var x=null
return A.f2(A.c([A.cz(x,x,B.r,x,x,new A.bB(B.L,x,x,A.cc(2),x,x,B.P),x,20,x,x,x,x,3),B.lb,A.bF(d,x,x,x,D.UP,x,x)],y.u),B.x,B.K,0)},
Dh(d,e){var x=A.a1(e).i("a4<1,f>")
x=A.a0(new A.a4(e,new C.a7K(this,d),x),x.i("at.E"))
return E.mT(F.bg,x,24,24)},
abZ(d,e){var x,w=null,v=A.bc(d,w,y.x).w.a.a,u=v<450?B.c.d5(v-48,0,1/0):360,t=e.h(0,"url")!=null?new C.a7I(this,e):w,s=A.bF(e.h(0,"title"),w,w,w,H.ln,w,w),r=A.bF(e.h(0,"tech"),w,w,w,I.zw,w,w),q=A.bF(e.h(0,"desc"),4,B.bR,w,H.lo,w,w),p=y.u,o=A.c([],p)
if(e.h(0,"url")!=null){x=A.ar1(w,w,w,w,w,w,w,w,w,B.L,w,B.z,B.aM,w,w,w,w,w,D.Tk,w)
o.push(new L.B6(!0,new C.a7J(this,e),w,w,w,x,B.r,w,!1,w,!0,w,new C.Uc(D.VD,D.Fy,x,w,w),w))}return A.di(E.kd(A.cP(A.c([s,I.z5,r,N.dT,q,F.bq,A.f2(o,B.eW,B.K,0)],p),B.a9,B.x,B.K),t,M.h3),w,u)},
ro(d){return this.ab0(d)},
ab0(d){var x=0,w=A.O(y.v)
var $async$ro=A.P(function(e,f){if(e===1)return A.L(f,w)
for(;;)switch(x){case 0:x=2
return A.T(O.vF(A.hd(d,0,null),Q.eH),$async$ro)
case 2:if(!f)A.G8().$1("Could not launch "+d)
return A.M(null,w)}})
return A.N($async$ro,w)}}
C.Uc.prototype={
L(d){var x,w=null,v=this.e.a,u=w
if(v==null)v=u
else{v=v.a7(B.bp)
v=v==null?w:v.r}x=v
if(x==null)x=14
v=A.bq(d,B.cg)
v=v==null?w:v.gcU()
v=A.z((v==null?B.b1:v).aF(x)/14,1,2)
L.awv(d)
v=A.Q(8,4,v-1)
v.toString
u=A.c([this.d,new A.rp(1,B.nK,this.c,w)],y.u)
return A.f2(u,B.x,B.bl,v)}}
var z=a.updateTypes([])
C.a7L.prototype={
$0(){var x=y.q
return A.z2(this.a,"/contact",x,x)},
$S:0}
C.a7K.prototype={
$1(d){return this.a.abZ(this.b,d)},
$S:488}
C.a7I.prototype={
$0(){return this.a.ro(this.b.h(0,"url"))},
$S:0}
C.a7J.prototype={
$0(){return this.a.ro(this.b.h(0,"url"))},
$S:0};(function inheritance(){var x=a.inheritMany,w=a.inherit
x(A.aB,[C.p7,C.Uc])
x(A.iM,[C.a7L,C.a7I,C.a7J])
w(C.a7K,A.fP)})()
A.lf(b.typeUniverse,JSON.parse('{"p7":{"aB":[],"f":[]},"Uc":{"aB":[],"f":[]}}'))
var y={c:A.W("p<bQ>"),k:A.W("p<aY<C,@>>"),u:A.W("p<f>"),x:A.W("f_"),w:A.W("C"),b:A.W("@"),q:A.W("G?"),v:A.W("~")};(function constants(){D.E4=new A.ax(16e4)
D.E9=new A.ax(24e4)
D.Ec=new A.ax(28e4)
D.El=new A.ax(8e4)
D.Fy=new A.lT(I.nT,16,null,null,null)
D.Tk=new A.j(!0,null,null,null,null,null,14,B.U,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null)
D.UP=new A.j(!0,B.k,null,null,null,null,22,B.bi,null,-0.5,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null)
D.Vs=new A.bJ("A collection of apps, backends, and systems I've built over the last 7 years.",null,G.im,null,null,null,null,null,null)
D.VD=new A.bJ("View Project",null,null,null,null,null,null,null,null)
D.RE=new A.j(!0,null,null,null,null,null,20,B.aA,null,-0.5,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null)
D.VG=new A.bJ("Want to see more or discuss a project?",null,D.RE,B.bP,null,null,null,null,null)
D.VK=new A.bJ("Let's Build Something Together",null,K.zs,null,null,null,null,null,null)})()};
(a=>{a["VG2X6xMR/d5QJmAersjvsHfyD40="]=a.current})($__dart_deferred_initializers__);