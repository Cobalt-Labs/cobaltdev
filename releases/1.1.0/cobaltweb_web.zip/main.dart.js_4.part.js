((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var J,A,C,B={cW:function cW(d,e,f){this.c=d
this.d=e
this.a=f},NW:function NW(d,e){var _=this
_.f=_.e=_.d=$
_.d0$=d
_.aV$=e
_.c=_.a=null},aeI:function aeI(d){this.a=d},Fr:function Fr(){},
kd(d,e,f){return new B.xP(d,f,e,null)},
xP:function xP(d,e,f,g){var _=this
_.c=d
_.f=e
_.r=f
_.a=g},
Qb:function Qb(){this.d=!1
this.c=this.a=null},
ahJ:function ahJ(d){this.a=d},
ahI:function ahI(d){this.a=d},
ahK:function ahK(d){this.a=d},
ahH:function ahH(d){this.a=d},
arh(d,e){var x
switch(e.a){case 0:x=d
break
case 1:x=new A.B(d.b,d.a)
break
default:x=null}return x},
ax4(d,e,f){var x
switch(f.a){case 0:x=e
break
case 1:x=e.gTl()
break
default:x=null}return x.aZ(d)},
aeX(d,e){return new A.B(d.a+e.a,Math.max(d.b,e.b))},
aGZ(d){return d.gp()},
aH_(d,e){var x=e.b
x.toString
y.e.a(x).a=d},
mU:function mU(d,e){this.a=d
this.b=e},
BR:function BR(d,e){this.a=d
this.b=e},
E8:function E8(d,e){this.a=d
this.b=1
this.c=e},
jx:function jx(d,e,f){this.ce$=d
this.ai$=e
this.a=f},
zT:function zT(d,e,f,g,h,i,j,k,l,m,n,o,p,q,r){var _=this
_.n=d
_.F=e
_.V=f
_.a0=g
_.a_=h
_.a8=i
_.a1=j
_.am=k
_.aQ=l
_.b3=!1
_.aG=m
_.bM$=n
_.a4$=o
_.cG$=p
_.dy=q
_.b=_.fy=null
_.c=0
_.y=_.d=null
_.z=!0
_.Q=null
_.as=!1
_.at=null
_.ay=$
_.ch=r
_.CW=!1
_.cx=$
_.cy=!0
_.db=!1
_.dx=$},
a99:function a99(d,e,f){this.a=d
this.b=e
this.c=f},
a9a:function a9a(d){this.a=d},
SW:function SW(){},
SX:function SX(){},
mT(d,e,f,g){return new B.NH(d,g,f,e,null)},
NH:function NH(d,e,f,g,h){var _=this
_.f=d
_.r=e
_.x=f
_.c=g
_.a=h},
AA(d,e){return new B.Mr(e,d,null)},
Mr:function Mr(d,e,f){this.w=d
this.x=e
this.a=f},
abM:function abM(d,e,f){this.a=d
this.b=e
this.c=f},
ve:function ve(d,e,f,g,h){var _=this
_.e=d
_.f=e
_.r=f
_.c=g
_.a=h},
TI:function TI(d,e){var _=this
_.c=_.b=_.a=_.CW=_.ay=_.p1=null
_.d=$
_.e=d
_.r=_.f=null
_.w=e
_.z=_.y=null
_.Q=!1
_.as=!0
_.at=!1},
E1:function E1(d,e,f,g,h,i,j){var _=this
_.n=d
_.F=e
_.V=f
_.a0=g
_.q$=h
_.dy=i
_.b=_.fy=null
_.c=0
_.y=_.d=null
_.z=!0
_.Q=null
_.as=!1
_.at=null
_.ay=$
_.ch=j
_.CW=!1
_.cx=$
_.cy=!0
_.db=!1
_.dx=$},
akH:function akH(d,e){this.a=d
this.b=e},
akG:function akG(d){this.a=d},
FN:function FN(){},
VU:function VU(){},
VV:function VV(){}},D
J=c[1]
A=c[0]
C=c[2]
B=a.updateHolder(c[12],B)
D=c[15]
B.cW.prototype={
ag(){return new B.NW(null,null)}}
B.NW.prototype={
az(){var x,w=this,v=null
w.aJ()
x=A.bH(v,D.Ek,v,v,w)
w.d=x
w.e=A.ch(C.bZ,x,v)
x=y.A
w.f=new A.al(A.ch(C.bZ,w.d,v),new A.ak(D.LC,C.f,x),x.i("al<ai.T>"))
x=w.a.d
if(x.a===0)w.d.bV()
else A.J0(x,new B.aeI(w),y.F)},
l(){var x=this.d
x===$&&A.a()
x.l()
this.a0a()},
L(d){var x,w=this.e
w===$&&A.a()
x=this.f
x===$&&A.a()
return new A.co(w,!1,A.mF(this.a.c,x,null,!0),null)}}
B.Fr.prototype={
l(){var x=this,w=x.aV$
if(w!=null)w.I(x.geh())
x.aV$=null
x.aB()},
bj(){this.c3()
this.bW()
this.ei()}}
B.xP.prototype={
ag(){return new B.Qb()}}
B.Qb.prototype={
L(d){var x,w,v,u,t,s,r=this,q=null,p=r.a,o=p.r,n=o!=null?C.bA:C.an
p=p.f
x=new A.aM(new Float64Array(16))
x.dq()
x.jn(0,r.d&&r.a.r!=null?-4:0,0)
w=r.d
v=w&&r.a.r!=null?D.CT:D.CE
u=A.cc(16)
t=A.iF(w&&r.a.r!=null?C.L.bN(0.45):C.L.bN(0.18),1)
w=r.d&&r.a.r!=null
s=y.c
w=w?A.c([new A.bQ(1,C.aU,C.L.bN(0.12),C.f,40)],s):A.c([new A.bQ(0,C.aU,C.l.bN(0.3),D.dH,16)],s)
return A.eu(A.eX(q,A.Xg(r.a.c,C.bZ,new A.bB(v,q,t,u,w,q,C.P),D.E7,q,p,x,q),C.a_,!1,q,q,q,q,q,q,q,q,q,q,q,q,q,q,o,q,q,q,q,q,q),n,q,new B.ahJ(r),new B.ahK(r),q)}}
B.mU.prototype={
E(){return"WrapAlignment."+this.b},
vp(d,e,f,g){var x,w,v=this
A:{if(D.bg===v){x=new A.ab(g?d:0,e)
break A}if(D.Xh===v){x=D.bg.vp(d,e,f,!g)
break A}w=D.Xi===v
if(w&&f<2){x=D.bg.vp(d,e,f,g)
break A}if(D.zN===v){x=new A.ab(d/2,e)
break A}if(w){x=new A.ab(0,d/(f-1)+e)
break A}if(D.Xj===v){x=d/f
x=new A.ab(x/2,x+e)
break A}if(D.Xk===v){x=d/(f+1)
x=new A.ab(x,x+e)
break A}x=null}return x}}
B.BR.prototype={
E(){return"WrapCrossAlignment."+this.b},
ga4y(){switch(this.a){case 0:var x=D.Xl
break
case 1:x=D.lA
break
case 2:x=D.Xm
break
default:x=null}return x},
ga1u(){switch(this.a){case 0:var x=0
break
case 1:x=1
break
case 2:x=0.5
break
default:x=null}return x}}
B.E8.prototype={
apr(d,e,f,g,h){var x=this,w=x.a
if(w.a+e.a+g-h>1e-10)return new B.E8(e,d)
else{x.a=B.aeX(w,B.aeX(e,new A.B(g,0)));++x.b
if(f)x.c=d
return null}}}
B.jx.prototype={}
B.zT.prototype={
snl(d){if(this.n===d)return
this.n=d
this.X()},
sfB(d){if(this.F===d)return
this.F=d
this.X()},
squ(d){if(this.V===d)return
this.V=d
this.X()},
saoT(d){if(this.a0===d)return
this.a0=d
this.X()},
saoW(d){if(this.a_===d)return
this.a_=d
this.X()},
sai7(d){if(this.a8===d)return
this.a8=d
this.X()},
ee(d){if(!(d.b instanceof B.jx))d.b=new B.jx(null,null,C.f)},
b5(d){var x,w,v,u,t,s=this
switch(s.n.a){case 0:x=s.a4$
for(w=A.m(s).i("a9.1"),v=0;x!=null;){u=x.gbr()
t=C.aw.dm(x.dy,1/0,u)
v=Math.max(v,t)
u=x.b
u.toString
x=w.a(u).ai$}return v
case 1:return s.ah(C.F,new A.a8(0,1/0,0,d),s.gc4()).a}},
b2(d){var x,w,v,u,t,s=this
switch(s.n.a){case 0:x=s.a4$
for(w=A.m(s).i("a9.1"),v=0;x!=null;){u=x.gb9()
t=C.a6.dm(x.dy,1/0,u)
v+=t
u=x.b
u.toString
x=w.a(u).ai$}return v
case 1:return s.ah(C.F,new A.a8(0,1/0,0,d),s.gc4()).a}},
b4(d){var x,w,v,u,t,s=this
switch(s.n.a){case 0:return s.ah(C.F,new A.a8(0,d,0,1/0),s.gc4()).b
case 1:x=s.a4$
for(w=A.m(s).i("a9.1"),v=0;x!=null;){u=x.gbq()
t=C.ax.dm(x.dy,1/0,u)
v=Math.max(v,t)
u=x.b
u.toString
x=w.a(u).ai$}return v}},
b1(d){var x,w,v,u,t,s=this
switch(s.n.a){case 0:return s.ah(C.F,new A.a8(0,d,0,1/0),s.gc4()).b
case 1:x=s.a4$
for(w=A.m(s).i("a9.1"),v=0;x!=null;){u=x.gby()
t=C.aT.dm(x.dy,1/0,u)
v+=t
u=x.b
u.toString
x=w.a(u).ai$}return v}},
ff(d){return this.xI(d)},
a57(d){var x
switch(this.n.a){case 0:x=d.a
break
case 1:x=d.b
break
default:x=null}return x},
a4T(d){var x
switch(this.n.a){case 0:x=d.b
break
case 1:x=d.a
break
default:x=null}return x},
a5a(d,e){var x
switch(this.n.a){case 0:x=new A.h(d,e)
break
case 1:x=new A.h(e,d)
break
default:x=null}return x},
gKg(){var x,w=this.a1
switch((w==null?C.H:w).a){case 1:w=!1
break
case 0:w=!0
break
default:w=null}switch(this.am.a){case 1:x=!1
break
case 0:x=!0
break
default:x=null}switch(this.n.a){case 0:w=new A.ab(w,x)
break
case 1:w=new A.ab(x,w)
break
default:w=null}return w},
d6(d,e){var x,w,v,u,t,s,r,q=this,p=null,o={}
if(q.a4$==null)return p
switch(q.n.a){case 0:x=new A.a8(0,d.b,0,1/0)
break
case 1:x=new A.a8(0,1/0,0,d.d)
break
default:x=p}w=q.L4(d,A.eR())
v=w.a
u=p
t=w.b
u=t
s=v
r=B.ax4(s,d,q.n)
o.a=null
q.Ob(u,s,r,new B.a99(o,x,e),new B.a9a(x))
return o.a},
cF(d){return this.afm(d)},
afm(d){var x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i=this,h=null
switch(i.n.a){case 0:x=d.b
x=new A.ab(new A.a8(0,x,0,1/0),x)
break
case 1:x=d.d
x=new A.ab(new A.a8(0,1/0,0,x),x)
break
default:x=h}w=x.a
v=h
u=x.b
v=u
t=w
s=i.a4$
for(x=A.m(i).i("a9.1"),r=0,q=0,p=0,o=0,n=0;s!=null;){m=A.atq(s,t)
l=i.a57(m)
k=i.a4T(m)
if(n>0&&p+l+i.V>v){r=Math.max(r,p)
q+=o+i.a_
p=0
o=0
n=0}p+=l
o=Math.max(o,k)
if(n>0)p+=i.V;++n
j=s.b
j.toString
s=x.a(j).ai$}q+=o
r=Math.max(r,p)
switch(i.n.a){case 0:x=new A.B(r,q)
break
case 1:x=new A.B(q,r)
break
default:x=h}return d.aZ(x)},
bv(){var x,w,v,u,t,s,r,q,p=this,o=y.a.a(A.q.prototype.gW.call(p))
if(p.a4$==null){p.fy=new A.B(A.z(0,o.a,o.b),A.z(0,o.c,o.d))
p.b3=!1
return}x=p.L4(o,A.lm())
w=x.a
v=null
u=x.b
v=u
t=w
s=p.n
r=B.ax4(t,o,s)
p.fy=B.arh(r,s)
s=r.a-t.a
q=r.b-t.b
p.b3=s<0||q<0
p.Ob(v,new A.B(s,q),r,B.aNZ(),B.aNY())},
L4(d,e){var x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h=this,g=null,f="Pattern matching error"
switch(h.n.a){case 0:x=d.b
x=new A.ab(new A.a8(0,x,0,1/0),x)
break
case 1:x=d.d
x=new A.ab(new A.a8(0,1/0,0,x),x)
break
default:x=g}w=x.a
v=g
u=x.b
v=u
t=w
s=h.gKg().a
r=s
q=h.V
p=A.c([],y.u)
o=h.a4$
x=A.m(h).i("a9.1")
n=g
m=C.z
while(o!=null){l=B.arh(e.$2(o,t),h.n)
k=n==null
j=k?new B.E8(l,o):n.apr(o,l,r,q,v)
if(j!=null){p.push(j)
if(k)k=g
else{k=n.a
l=new A.B(k.b,k.a)
k=l}if(k==null)k=C.z
l=new A.B(m.a+k.a,Math.max(m.b,k.b))
m=l
n=j}k=o.b
k.toString
o=x.a(k).ai$}x=h.a_
k=p.length
i=n.a
m=B.aeX(m,B.aeX(new A.B(x*(k-1),0),new A.B(i.b,i.a)))
return new A.ab(new A.B(m.b,m.a),p)},
Ob(b1,b2,b3,b4,b5){var x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f,e,d,a0,a1,a2,a3=this,a4=null,a5=a3.V,a6=Math.max(0,b2.b),a7=a3.gKg(),a8=a7.a,a9=a4,b0=a7.b
a9=b0
x=a3.a8
if(a9)x=x.ga4y()
w=a3.a0.vp(a6,a3.a_,b1.length,a9)
v=w.a
u=a4
t=w.b
u=t
s=a8?a3.gpe():a3.gpd()
for(r=J.bo(a9?new A.ca(b1,A.a1(b1).i("ca<1>")):b1),q=b3.a,p=v;r.v();){o=r.gN()
n=o.a
m=n.b
l=o.b
k=Math.max(0,q-n.a)
j=a3.F.vp(k,a5,l,a8)
i=j.a
h=a4
g=j.b
h=g
f=o.c
e=l
d=i
for(;;){if(!(f!=null&&e>0))break
a0=B.arh(b5.$1(f),a3.n)
a1=a4
a2=a0.b
a1=a2
b4.$2(a3.a5a(d,p+x.ga1u()*(m-a1)),f)
d+=a0.a+h
f=s.$1(f);--e}p+=m+u}},
co(d,e){return this.t5(d,e)},
aA(d,e){var x,w=this,v=w.b3&&w.aQ!==C.r,u=w.aG
if(v){v=w.cx
v===$&&A.a()
x=w.gp()
u.sao(d.l1(v,e,new A.n(0,0,0+x.a,0+x.b),w.gSA(),w.aQ,u.a))}else{u.sao(null)
w.nc(d,e)}},
l(){this.aG.sao(null)
this.f8()}}
B.SW.prototype={
al(d){var x,w,v
this.dD(d)
x=this.a4$
for(w=y.e;x!=null;){x.al(d)
v=x.b
v.toString
x=w.a(v).ai$}},
ad(){var x,w,v
this.dE()
x=this.a4$
for(w=y.e;x!=null;){x.ad()
v=x.b
v.toString
x=w.a(v).ai$}}}
B.SX.prototype={}
B.NH.prototype={
aI(d){var x=A.d9(d)
x=new B.zT(C.aq,this.f,this.r,D.bg,this.x,D.lA,x,C.bT,C.r,A.ag(),0,null,null,new A.aK(),A.ag())
x.aH()
x.U(0,null)
return x},
aN(d,e){var x
e.snl(C.aq)
e.sfB(this.f)
e.squ(this.r)
e.saoT(D.bg)
e.saoW(this.x)
e.sai7(D.lA)
x=A.d9(d)
if(e.a1!=x){e.a1=x
e.X()}if(e.am!==C.bT){e.am=C.bT
e.X()}if(C.r!==e.aQ){e.aQ=C.r
e.av()
e.aW()}}}
B.Mr.prototype={
L(d){var x,w,v,u=null,t={},s=A.aza(d,C.aK,!1)
t.a=this.x
x=A.avJ(d,C.aK)
w=x?A.KZ(d):u
v=A.aqN(s,C.Z,w,C.a_,!1,C.aG,u,this.w,u,u,u,new B.abM(t,this,s))
A.pp(d)
return x&&w!=null?A.avI(v):v}}
B.ve.prototype={
aI(d){var x=new B.E1(this.e,this.f,this.r,A.ag(),null,new A.aK(),A.ag())
x.aH()
x.saR(null)
return x},
aN(d,e){var x
e.sh2(this.e)
e.siC(this.f)
x=this.r
if(x!==e.V){e.V=x
e.av()
e.aW()}},
bQ(){return new B.TI(this,C.a5)}}
B.TI.prototype={}
B.E1.prototype={
sh2(d){if(d===this.n)return
this.n=d
this.X()},
siC(d){var x=this,w=x.F
if(d===w)return
if(x.y!=null)w.I(x.gvL())
x.F=d
if(x.y!=null)d.Z(x.gvL())
x.X()},
a8z(){this.av()
this.aW()},
ee(d){if(!(d.b instanceof A.ce))d.b=new A.ce()},
al(d){this.a0v(d)
this.F.Z(this.gvL())},
ad(){this.F.I(this.gvL())
this.a0w()},
gem(){return!0},
gadH(){switch(A.b7(this.n).a){case 0:var x=this.gp().a
break
case 1:x=this.gp().b
break
default:x=null}return x},
gvU(){var x=this,w=x.q$
if(w==null)return 0
switch(A.b7(x.n).a){case 0:w=w.gp().a-x.gp().a
break
case 1:w=w.gp().b-x.gp().b
break
default:w=null}return Math.max(0,A.hP(w))},
Mk(d){var x
switch(A.b7(this.n).a){case 0:x=new A.a8(0,1/0,d.c,d.d)
break
case 1:x=new A.a8(d.a,d.b,0,1/0)
break
default:x=null}return x},
b5(d){var x=this.q$
x=x==null?null:x.ah(C.aw,d,x.gbr())
return x==null?0:x},
b2(d){var x=this.q$
x=x==null?null:x.ah(C.a6,d,x.gb9())
return x==null?0:x},
b4(d){var x=this.q$
x=x==null?null:x.ah(C.ax,d,x.gbq())
return x==null?0:x},
b1(d){var x=this.q$
x=x==null?null:x.ah(C.aT,d,x.gby())
return x==null?0:x},
cF(d){var x=this.q$
if(x==null)return new A.B(A.z(0,d.a,d.b),A.z(0,d.c,d.d))
return d.aZ(x.ah(C.F,this.Mk(d),x.gc4()))},
bv(){var x,w,v=this,u=y.a.a(A.q.prototype.gW.call(v)),t=v.q$
if(t==null)v.fy=new A.B(A.z(0,u.a,u.b),A.z(0,u.c,u.d))
else{t.bX(v.Mk(u),!0)
v.fy=u.aZ(v.q$.gp())}t=v.F.at
if(t!=null)if(t>v.gvU()){t=v.F
x=v.gvU()
w=v.F.at
w.toString
t.Fi(x-w)}else{t=v.F
x=t.at
x.toString
if(x<0)t.Fi(0-x)}v.F.x4(v.gadH())
v.F.x3(0,v.gvU())},
rq(d){var x,w=this
switch(w.n.a){case 0:x=new A.h(0,d-w.q$.gp().b+w.gp().b)
break
case 3:x=new A.h(d-w.q$.gp().a+w.gp().a,0)
break
case 1:x=new A.h(-d,0)
break
case 2:x=new A.h(0,-d)
break
default:x=null}return x},
Py(d){var x,w,v=this
switch(v.V.a){case 0:return!1
case 1:case 2:case 3:x=d.a
if(!(x<0)){w=d.b
x=w<0||x+v.q$.gp().a>v.gp().a||w+v.q$.gp().b>v.gp().b}else x=!0
return x}},
aA(d,e){var x,w,v,u,t,s=this
if(s.q$!=null){x=s.F.at
x.toString
w=s.rq(x)
x=new B.akH(s,w)
v=s.a0
if(s.Py(w)){u=s.cx
u===$&&A.a()
t=s.gp()
v.sao(d.l1(u,e,new A.n(0,0,0+t.a,0+t.b),x,s.V,v.a))}else{v.sao(null)
x.$2(d,e)}}},
l(){this.a0.sao(null)
this.f8()},
cY(d,e){var x,w=this.F.at
w.toString
x=this.rq(w)
e.dn(x.a,x.b,0,1)},
lU(d){var x=this,w=x.F.at
w.toString
w=x.Py(x.rq(w))
if(w){w=x.gp()
return new A.n(0,0,0+w.a,0+w.b)}return null},
co(d,e){var x,w=this
if(w.q$!=null){x=w.F.at
x.toString
return d.iS(new B.akG(w),w.rq(x),e)}return!1},
o1(d,e,f,g){var x,w,v,u,t,s,r,q,p,o,n=this,m=null
A.b7(n.n)
if(g==null)g=d.gjW()
if(!(d instanceof A.r)){x=n.F.at
x.toString
return new A.pm(x,g)}w=A.db(d.aD(n.q$),g)
v=n.q$.gp()
switch(n.n.a){case 0:x=w.d
x=new A.fG(n.gp().b,v.b-x,x-w.b)
break
case 3:x=w.c
x=new A.fG(n.gp().a,v.a-x,x-w.a)
break
case 1:x=w.a
x=new A.fG(n.gp().a,x,w.c-x)
break
case 2:x=w.b
x=new A.fG(n.gp().b,x,w.d-x)
break
default:x=m}u=x.a
t=m
s=m
r=x.b
q=x.c
s=q
t=r
p=u
o=t-(p-s)*e
return new A.pm(o,w.d2(n.rq(o)))},
Aa(d,e,f){return this.o1(d,e,null,f)},
eg(d,e,f,g){this.JE(d,null,f,A.aw3(d,e,f,this.F,g,this))},
qt(){return this.eg(C.b4,null,C.v,null)},
mD(d){return this.eg(C.b4,null,C.v,d)},
o9(d,e,f){return this.eg(d,null,e,f)},
mE(d,e){return this.eg(C.b4,d,C.v,e)},
Fx(d){var x,w,v=this,u=v.gvU(),t=v.F.at
t.toString
x=u-t
switch(v.n.a){case 0:v.gp()
v.gp()
u=v.gp()
t=v.gp()
w=v.F.at
w.toString
return new A.n(0,0-x,0+u.a,0+t.b+w)
case 1:v.gp()
u=v.F.at
u.toString
v.gp()
return new A.n(0-u,0,0+v.gp().a+x,0+v.gp().b)
case 2:v.gp()
v.gp()
u=v.F.at
u.toString
return new A.n(0,0-u,0+v.gp().a,0+v.gp().b+x)
case 3:v.gp()
v.gp()
u=v.gp()
t=v.F.at
t.toString
return new A.n(0-x,0,0+u.a+t,0+v.gp().b)}},
$iLe:1}
B.FN.prototype={
al(d){var x
this.dD(d)
x=this.q$
if(x!=null)x.al(d)},
ad(){this.dE()
var x=this.q$
if(x!=null)x.ad()}}
B.VU.prototype={}
B.VV.prototype={}
var z=a.updateTypes(["D(D)","ve(S,hg)","~()","~({curve:ep,descendant:q?,duration:ax,rect:n?})","B(r)","~(h,r)"])
B.aeI.prototype={
$0(){var x=this.a
if(x.c!=null){x=x.d
x===$&&A.a()
x.bV()}},
$S:34}
B.ahJ.prototype={
$1(d){var x=this.a
return x.aj(new B.ahI(x))},
$S:46}
B.ahI.prototype={
$0(){return this.a.d=!0},
$S:0}
B.ahK.prototype={
$1(d){var x=this.a
return x.aj(new B.ahH(x))},
$S:31}
B.ahH.prototype={
$0(){return this.a.d=!1},
$S:0}
B.a99.prototype={
$2(d,e){var x=this.a
x.a=A.qH(x.a,A.apo(e.ec(this.b,this.c),d.b))},
$S:489}
B.a9a.prototype={
$1(d){return d.ah(C.F,this.a,d.gc4())},
$S:490}
B.abM.prototype={
$2(d,e){return new B.ve(this.c,e,C.Z,this.a.a,null)},
$S:z+1}
B.akH.prototype={
$2(d,e){var x=this.a.q$
x.toString
d.df(x,e.R(0,this.b))},
$S:15}
B.akG.prototype={
$2(d,e){return this.a.q$.cg(d,e)},
$S:12};(function aliases(){var x=B.Fr.prototype
x.a0a=x.l
x=B.FN.prototype
x.a0v=x.al
x.a0w=x.ad})();(function installTearOffs(){var x=a._static_1,w=a._static_2,v=a._instance_1u,u=a._instance_0u,t=a.installInstanceTearOff
x(B,"aNY","aGZ",4)
w(B,"aNZ","aH_",5)
var s
v(s=B.zT.prototype,"gbr","b5",0)
v(s,"gb9","b2",0)
v(s,"gbq","b4",0)
v(s,"gby","b1",0)
u(s=B.E1.prototype,"gvL","a8z",2)
v(s,"gbr","b5",0)
v(s,"gb9","b2",0)
v(s,"gbq","b4",0)
v(s,"gby","b1",0)
t(s,"go8",0,0,null,["$4$curve$descendant$duration$rect","$0","$1$rect","$3$curve$duration$rect","$2$descendant$rect"],["eg","qt","mD","o9","mE"],3,0,0)})();(function inheritance(){var x=a.mixinHard,w=a.mixin,v=a.inheritMany,u=a.inherit
v(A.V,[B.cW,B.xP])
v(A.a2,[B.Fr,B.Qb])
u(B.NW,B.Fr)
v(A.iM,[B.aeI,B.ahI,B.ahH])
v(A.fP,[B.ahJ,B.ahK,B.a9a])
v(A.uC,[B.mU,B.BR])
u(B.E8,A.G)
u(B.jx,A.nO)
v(A.r,[B.SW,B.FN])
u(B.SX,B.SW)
u(B.zT,B.SX)
v(A.nK,[B.a99,B.abM,B.akH,B.akG])
u(B.NH,A.dX)
u(B.Mr,A.aB)
u(B.ve,A.aW)
u(B.VU,A.tI)
u(B.VV,B.VU)
u(B.TI,B.VV)
u(B.E1,B.FN)
x(B.Fr,A.dx)
x(B.SW,A.a9)
w(B.SX,A.cT)
x(B.FN,A.aD)
w(B.VU,A.z3)
w(B.VV,A.Nx)})()
A.lf(b.typeUniverse,JSON.parse('{"cW":{"V":[],"f":[]},"NW":{"a2":["cW"]},"xP":{"V":[],"f":[]},"Qb":{"a2":["xP"]},"jx":{"el":[],"dG":["r"],"ce":[]},"zT":{"cT":["r","jx"],"r":[],"a9":["r","jx"],"q":[],"ah":[],"a9.1":"jx","cT.1":"jx","a9.0":"r"},"NH":{"dX":[],"an":[],"f":[]},"ve":{"aW":[],"an":[],"f":[]},"Mr":{"aB":[],"f":[]},"TI":{"aJ":[],"aV":[],"S":[]},"E1":{"r":[],"aD":["r"],"Le":[],"q":[],"ah":[]}}'))
var y={a:A.W("a8"),c:A.W("p<bQ>"),u:A.W("p<E8>"),F:A.W("b_"),A:A.W("ak<h>"),e:A.W("jx")};(function constants(){D.CE=new A.w(1,0.06274509803921569,0.054901960784313725,0.13333333333333333,C.e)
D.CT=new A.w(1,0.08627450980392157,0.07058823529411765,0.16470588235294117,C.e)
D.E7=new A.ax(22e4)
D.Ek=new A.ax(55e4)
D.bq=new A.cs(null,24,null,null)
D.dH=new A.h(0,4)
D.LC=new A.h(0,0.06)
D.bg=new B.mU(0,"start")
D.Xh=new B.mU(1,"end")
D.zN=new B.mU(2,"center")
D.Xi=new B.mU(3,"spaceBetween")
D.Xj=new B.mU(4,"spaceAround")
D.Xk=new B.mU(5,"spaceEvenly")
D.lA=new B.BR(0,"start")
D.Xl=new B.BR(1,"end")
D.Xm=new B.BR(2,"center")})()};
(a=>{a["PHStWa2Oheu6GuJMMJTrd8qRaUk="]=a.current})($__dart_deferred_initializers__);