((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B,C
A=c[0]
B=c[2]
C=c[29]
var z=a.updateTypes([]);(function constants(){C.jf=new A.w(1,0.39215686274509803,0.4549019607843137,0.5450980392156862,B.e)})()};
(a=>{a["YQl+qUDF7wxLIB9lD6eY0XVWV/E="]=a.current})($__dart_deferred_initializers__);