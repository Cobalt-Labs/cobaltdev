((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B
A=c[0]
B=c[16]
var z=a.updateTypes([]);(function constants(){B.fd=new A.cs(null,60,null,null)})()};
(a=>{a["lYhja8JyXQEb54KQcWkmUB8TXIA="]=a.current})($__dart_deferred_initializers__);